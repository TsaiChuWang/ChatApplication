package com.xg.server.data;

import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class DiscussionGroups{

	private static List<Socket> mList = new ArrayList<Socket>();
	
	

}
