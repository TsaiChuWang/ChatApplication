# Android-Socket-ChatRoom
## Android Socket 实现群聊功能
 工程分为两个端，java和Android，效果图如下:</br>
![Image](https://github.com/SunnyLine/Android-Socket-ChatRoom/blob/master/images/20160416141020.png)</br>
![Image](https://github.com/SunnyLine/Android-Socket-ChatRoom/blob/master/images/20160416141118.png)</br>
![Image](https://github.com/SunnyLine/Android-Socket-ChatRoom/blob/master/images/20160416141148.png)</br>
![Image](https://github.com/SunnyLine/Android-Socket-ChatRoom/blob/master/images/20160416141205.png)</br>
![Image](https://github.com/SunnyLine/Android-Socket-ChatRoom/blob/master/images/20160416161021.png)</br>
